import os 
import psycopg2

url = os.popen("heroku config:get DATABASE_URL -a eddiecloud").read()[:-1]
conn = psycopg2.connect(url, sslmode = 'require')

cursor = conn.cursor()

#table_columns = '(user_name, temperature)'
order =  ''' INSERT INTO USER_TABLE (user_name, exercise, temperature)
             VALUES ('eddie', 'running','38');'''

cursor.execute(order)
conn.commit()

count = cursor.rowcount
print(count, "successfully insert")

cursor.close()
conn.close()