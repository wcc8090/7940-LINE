import os 
import psycopg2

url = os.popen("heroku config:get DATABASE_URL -a eddiecloud").read()[:-1]
conn = psycopg2.connect(url, sslmode = 'require')

cursor = conn.cursor()

order = ''' CREATE TABLE USER_TABLE(
    user_name varchar(30) PRIMARY KEY,
    exercise varchar(100),
    temperature int
);'''

cursor.execute(order)
conn.commit()

cursor.close()
conn.close()