import os 
import psycopg2

url = os.popen("heroku config:get DATABASE_URL -a eddiecloud").read()[:-1]
conn = psycopg2.connect(url, sslmode = 'require')

cursor = conn.cursor()
order = ''' CREATE TABLE HEALTH_TABLE(
    user_name CHAR PRIMARY KEY,
    temperature NUMERIC NOT NULL,
);'''

cursor(order)
conn.commit()

cursor.close()
conn.close()